import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/app/components/ui/dialog';
import { Badge } from '@/app/components/ui/badge';
import { BookOpen, Plus, Trash2, Calendar, Heart, Users, Home } from 'lucide-react';

const mockClasses = [
  {
    id: 1,
    name: "Math 101",
    color: "blue",
    assignments: [
      { id: 1, title: "Homework 5", dueDate: "2026-01-20", penalty: 10 },
      { id: 2, title: "Quiz 3", dueDate: "2026-01-25", penalty: 15 },
    ]
  },
  {
    id: 2,
    name: "English 202",
    color: "green",
    assignments: [
      { id: 3, title: "Essay Draft", dueDate: "2026-01-21", penalty: 15 },
    ]
  },
  {
    id: 3,
    name: "Physics 150",
    color: "purple",
    assignments: [
      { id: 4, title: "Lab Report", dueDate: "2026-01-19", penalty: 10 },
      { id: 5, title: "Problem Set 4", dueDate: "2026-01-23", penalty: 10 },
    ]
  },
];

export function ClassesPage() {
  const [classes, setClasses] = useState(mockClasses);
  const [isAddClassOpen, setIsAddClassOpen] = useState(false);
  const [isAddAssignmentOpen, setIsAddAssignmentOpen] = useState(false);
  const [selectedClass, setSelectedClass] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Navigation */}
      <nav className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🐕</span>
              <h1 className="text-xl font-bold text-gray-900">Pibble Care</h1>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" asChild>
                <Link to="/dashboard">
                  <Home className="mr-2 h-4 w-4" />
                  Dashboard
                </Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/classes">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Classes
                </Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/groups">
                  <Users className="mr-2 h-4 w-4" />
                  Groups
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Classes</h1>
            <p className="text-gray-600 mt-1">Manage your classes and assignments</p>
          </div>
          <Dialog open={isAddClassOpen} onOpenChange={setIsAddClassOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Class
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Class</DialogTitle>
                <DialogDescription>
                  Create a new class to track assignments and protect your pibble.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="className">Class Name</Label>
                  <Input id="className" placeholder="e.g., Math 101" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="classColor">Color Theme</Label>
                  <div className="flex gap-2">
                    {['blue', 'green', 'purple', 'red', 'yellow', 'pink'].map((color) => (
                      <button
                        key={color}
                        className={`w-10 h-10 rounded-full bg-${color}-500 hover:ring-2 hover:ring-${color}-600 transition-all`}
                      />
                    ))}
                  </div>
                </div>
                <Button className="w-full">Create Class</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Classes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {classes.map((cls) => (
            <Card key={cls.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full bg-${cls.color}-500`} />
                    {cls.name}
                  </CardTitle>
                  <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-700">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <CardDescription>
                  {cls.assignments.length} assignment{cls.assignments.length !== 1 ? 's' : ''}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Assignments */}
                {cls.assignments.map((assignment) => (
                  <div key={assignment.id} className="p-3 border rounded-lg bg-gray-50">
                    <h4 className="font-medium text-sm text-gray-900">{assignment.title}</h4>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs text-gray-600 flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {new Date(assignment.dueDate).toLocaleDateString()}
                      </span>
                      <span className="text-xs text-red-600 flex items-center gap-1">
                        <Heart className="h-3 w-3" />
                        -{assignment.penalty} HP
                      </span>
                    </div>
                  </div>
                ))}

                {/* Add Assignment Button */}
                <Dialog 
                  open={isAddAssignmentOpen && selectedClass === cls.id} 
                  onOpenChange={(open) => {
                    setIsAddAssignmentOpen(open);
                    if (open) setSelectedClass(cls.id);
                  }}
                >
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="w-full">
                      <Plus className="mr-2 h-3 w-3" />
                      Add Assignment
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Assignment to {cls.name}</DialogTitle>
                      <DialogDescription>
                        Missing this assignment will damage your pibble's health.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="assignmentTitle">Assignment Title</Label>
                        <Input id="assignmentTitle" placeholder="e.g., Homework 6" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="dueDate">Due Date</Label>
                        <Input id="dueDate" type="date" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="penalty">Health Penalty (if missed)</Label>
                        <Input 
                          id="penalty" 
                          type="number" 
                          placeholder="10" 
                          min="1"
                          max="100"
                        />
                        <p className="text-xs text-gray-600">
                          How much health your pibble will lose if you miss this assignment
                        </p>
                      </div>
                      <Button className="w-full">Add Assignment</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          ))}

          {/* Add Class Card */}
          <Card className="border-dashed border-2 hover:border-purple-400 transition-colors cursor-pointer">
            <CardContent className="flex flex-col items-center justify-center h-full min-h-64 text-center p-6">
              <Button 
                variant="ghost" 
                size="lg"
                className="flex-col h-auto py-8"
                onClick={() => setIsAddClassOpen(true)}
              >
                <Plus className="h-12 w-12 mb-2 text-gray-400" />
                <span className="text-gray-600">Add New Class</span>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
