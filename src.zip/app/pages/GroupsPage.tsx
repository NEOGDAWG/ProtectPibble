import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Textarea } from '@/app/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/app/components/ui/dialog';
import { Badge } from '@/app/components/ui/badge';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { Users, Plus, Home, BookOpen, AlertTriangle, UserPlus, Copy, Check } from 'lucide-react';

const mockGroups = [
  {
    id: 1,
    name: "Study Squad",
    consequence: "Buy coffee for the group",
    members: [
      { id: 1, name: "You", health: 75 },
      { id: 2, name: "Alice", health: 90 },
      { id: 3, name: "Bob", health: 45 },
      { id: 4, name: "Charlie", health: 100 },
    ],
    inviteCode: "STUDY123"
  },
  {
    id: 2,
    name: "Accountability Crew",
    consequence: "Do 50 pushups and post video",
    members: [
      { id: 1, name: "You", health: 75 },
      { id: 5, name: "Diana", health: 60 },
      { id: 6, name: "Eve", health: 85 },
    ],
    inviteCode: "ACCT456"
  },
];

export function GroupsPage() {
  const [groups, setGroups] = useState(mockGroups);
  const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
  const [isJoinGroupOpen, setIsJoinGroupOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const getHealthColor = (health: number) => {
    if (health > 60) return 'text-green-600';
    if (health > 30) return 'text-yellow-600';
    if (health > 0) return 'text-red-600';
    return 'text-gray-400';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Navigation */}
      <nav className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🐕</span>
              <h1 className="text-xl font-bold text-gray-900">Pibble Care</h1>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" asChild>
                <Link to="/dashboard">
                  <Home className="mr-2 h-4 w-4" />
                  Dashboard
                </Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/classes">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Classes
                </Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/groups">
                  <Users className="mr-2 h-4 w-4" />
                  Groups
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Groups</h1>
            <p className="text-gray-600 mt-1">Stay accountable with friends</p>
          </div>
          <div className="flex gap-2">
            <Dialog open={isJoinGroupOpen} onOpenChange={setIsJoinGroupOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <UserPlus className="mr-2 h-4 w-4" />
                  Join Group
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Join a Group</DialogTitle>
                  <DialogDescription>
                    Enter an invite code to join an existing group.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="inviteCode">Invite Code</Label>
                    <Input 
                      id="inviteCode" 
                      placeholder="e.g., STUDY123" 
                      className="uppercase"
                    />
                  </div>
                  <Button className="w-full">Join Group</Button>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isCreateGroupOpen} onOpenChange={setIsCreateGroupOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Group
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Group</DialogTitle>
                  <DialogDescription>
                    Set up a new accountability group and define the consequence for pibble death.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="groupName">Group Name</Label>
                    <Input id="groupName" placeholder="e.g., Study Squad" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="consequence">Consequence (if pibble dies)</Label>
                    <Textarea 
                      id="consequence" 
                      placeholder="e.g., Buy coffee for everyone in the group"
                      rows={3}
                    />
                    <p className="text-xs text-gray-600">
                      What members must do if their pibble's health reaches zero
                    </p>
                  </div>
                  <Button className="w-full">Create Group</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Info Banner */}
        <Card className="mb-6 bg-purple-50 border-purple-200">
          <CardContent className="flex items-start gap-3 p-4">
            <AlertTriangle className="h-5 w-5 text-purple-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm text-purple-900">
                <strong>How it works:</strong> Join groups to stay accountable with friends. 
                If your pibble's health reaches zero, you must complete the group's consequence!
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Groups List */}
        <div className="space-y-6">
          {groups.map((group) => (
            <Card key={group.id} className="overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-purple-100 to-blue-100">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      {group.name}
                    </CardTitle>
                    <CardDescription className="mt-2">
                      {group.members.length} member{group.members.length !== 1 ? 's' : ''}
                    </CardDescription>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleCopyCode(group.inviteCode)}
                    className="bg-white"
                  >
                    {copiedCode === group.inviteCode ? (
                      <>
                        <Check className="mr-2 h-3 w-3" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="mr-2 h-3 w-3" />
                        {group.inviteCode}
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                {/* Consequence */}
                <div className="mb-6 p-4 bg-amber-50 border-2 border-amber-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                    <span className="font-semibold text-amber-900 text-sm">Death Consequence</span>
                  </div>
                  <p className="text-sm text-amber-800">{group.consequence}</p>
                </div>

                {/* Members */}
                <div>
                  <h3 className="font-semibold text-sm text-gray-700 mb-3">Members</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                    {group.members.map((member) => (
                      <div key={member.id} className="flex items-center gap-3 p-3 border rounded-lg bg-white">
                        <Avatar>
                          <AvatarFallback className="bg-purple-100 text-purple-700">
                            {member.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm text-gray-900 truncate">
                            {member.name}
                          </div>
                          <div className={`text-xs font-semibold ${getHealthColor(member.health)}`}>
                            {member.health}% HP
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Empty State */}
          {groups.length === 0 && (
            <Card className="border-dashed border-2">
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <Users className="h-16 w-16 text-gray-300 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Groups Yet</h3>
                <p className="text-gray-600 mb-6 max-w-md">
                  Create or join a group to stay accountable with friends and add some fun stakes to your productivity!
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setIsJoinGroupOpen(true)}>
                    <UserPlus className="mr-2 h-4 w-4" />
                    Join Group
                  </Button>
                  <Button onClick={() => setIsCreateGroupOpen(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Group
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
