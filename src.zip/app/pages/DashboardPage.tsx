import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Progress } from '@/app/components/ui/progress';
import { Badge } from '@/app/components/ui/badge';
import { Checkbox } from '@/app/components/ui/checkbox';
import { Heart, BookOpen, Users, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';

// Mock data
const mockPibble = {
  name: "Pibby",
  health: 75,
  maxHealth: 100,
  status: "healthy",
  image: "🐕"
};

const mockAssignments = [
  { id: 1, class: "Math 101", title: "Homework 5", dueDate: "2026-01-20", completed: false, penalty: 10 },
  { id: 2, class: "English 202", title: "Essay Draft", dueDate: "2026-01-21", completed: false, penalty: 15 },
  { id: 3, class: "Physics 150", title: "Lab Report", dueDate: "2026-01-19", completed: true, penalty: 10 },
  { id: 4, class: "History 101", title: "Reading Quiz", dueDate: "2026-01-22", completed: false, penalty: 5 },
];

const mockGroups = [
  { id: 1, name: "Study Squad", consequence: "Buy coffee for the group" },
  { id: 2, name: "Accountability Crew", consequence: "Do 50 pushups" },
];

export function DashboardPage() {
  const [pibble, setPibble] = useState(mockPibble);
  const [assignments, setAssignments] = useState(mockAssignments);

  const handleToggleAssignment = (id: number) => {
    setAssignments(assignments.map(a => 
      a.id === id ? { ...a, completed: !a.completed } : a
    ));
  };

  const getHealthColor = (health: number) => {
    if (health > 60) return 'bg-green-500';
    if (health > 30) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getHealthStatus = (health: number) => {
    if (health > 60) return 'Healthy';
    if (health > 30) return 'Concerned';
    if (health > 0) return 'Critical';
    return 'Dead';
  };

  const upcomingAssignments = assignments.filter(a => !a.completed);
  const isDead = pibble.health === 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Navigation */}
      <nav className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🐕</span>
              <h1 className="text-xl font-bold text-gray-900">Pibble Care</h1>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" asChild>
                <Link to="/dashboard">
                  <Heart className="mr-2 h-4 w-4" />
                  Dashboard
                </Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/classes">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Classes
                </Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/groups">
                  <Users className="mr-2 h-4 w-4" />
                  Groups
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Pibble Card */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{pibble.name} the Pibble</span>
                <Badge variant={isDead ? "destructive" : "default"}>
                  {getHealthStatus(pibble.health)}
                </Badge>
              </CardTitle>
              <CardDescription>
                {isDead ? "Your pibble has died! Complete your consequence!" : "Keep your pibble healthy by completing assignments!"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Pibble Avatar */}
              <div className="flex justify-center">
                <div className={`text-9xl ${isDead ? 'grayscale opacity-50' : ''}`}>
                  {pibble.image}
                </div>
              </div>

              {/* Health Bar */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-1">
                    <Heart className="h-4 w-4 text-red-500" />
                    Health
                  </span>
                  <span className="font-semibold">{pibble.health}/{pibble.maxHealth}</span>
                </div>
                <Progress 
                  value={pibble.health} 
                  className="h-3"
                />
                {pibble.health < 30 && pibble.health > 0 && (
                  <div className="flex items-center gap-2 text-amber-600 text-sm">
                    <AlertTriangle className="h-4 w-4" />
                    <span>Warning: Health is critical!</span>
                  </div>
                )}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {assignments.filter(a => a.completed).length}
                  </div>
                  <div className="text-xs text-gray-600">Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">
                    {upcomingAssignments.length}
                  </div>
                  <div className="text-xs text-gray-600">Pending</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Assignments */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Upcoming Assignments</span>
                <Button size="sm" asChild>
                  <Link to="/classes">Add Assignment</Link>
                </Button>
              </CardTitle>
              <CardDescription>
                Complete assignments on time to keep your pibble healthy!
              </CardDescription>
            </CardHeader>
            <CardContent>
              {upcomingAssignments.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <CheckCircle2 className="h-12 w-12 mx-auto mb-3 text-green-500" />
                  <p className="font-medium">All caught up!</p>
                  <p className="text-sm">No pending assignments. Your pibble is happy! 🎉</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {assignments.map((assignment) => (
                    <div
                      key={assignment.id}
                      className={`p-4 border-2 rounded-lg transition-all ${
                        assignment.completed
                          ? 'bg-green-50 border-green-200 opacity-60'
                          : 'bg-white border-gray-200 hover:border-purple-300'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <Checkbox
                          checked={assignment.completed}
                          onCheckedChange={() => handleToggleAssignment(assignment.id)}
                          className="mt-1"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className={`font-semibold ${assignment.completed ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                              {assignment.title}
                            </h3>
                            <Badge variant="outline" className="text-xs">
                              {assignment.class}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 mt-1 text-sm text-gray-600">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              Due: {new Date(assignment.dueDate).toLocaleDateString()}
                            </span>
                            <span className="flex items-center gap-1 text-red-600">
                              <Heart className="h-3 w-3" />
                              -{assignment.penalty} HP if missed
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Groups & Consequences */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle>Your Groups & Consequences</CardTitle>
              <CardDescription>
                If your pibble dies, you must complete these consequences!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mockGroups.map((group) => (
                  <div key={group.id} className="p-4 border-2 border-dashed border-gray-300 rounded-lg bg-amber-50">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="h-5 w-5 text-purple-600" />
                      <h3 className="font-semibold text-gray-900">{group.name}</h3>
                    </div>
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Consequence:</span> {group.consequence}
                    </p>
                  </div>
                ))}
                <Button variant="outline" className="h-full min-h-24 border-dashed" asChild>
                  <Link to="/groups">
                    <Users className="mr-2 h-4 w-4" />
                    Join or Create Group
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
